object Problem1{
    def main(args:Array[String]){
        val str = "https://www.google.com"
        val reverse = str.reverse.toUpperCase()
        println(s"$reverse")
    }
}