object Problem4{
    def main(args:Array[String]){
        val str = "http://www.google.com"
        val charToFind = str.charAt(7)
        println(s"The 8th character literal in $str = $charToFind")
    }
}